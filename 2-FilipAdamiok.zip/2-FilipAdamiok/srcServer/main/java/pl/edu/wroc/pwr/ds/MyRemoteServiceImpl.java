package pl.edu.wroc.pwr.ds;

import org.apache.log4j.Logger;

import java.awt.Checkbox;
import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;

import pl.edu.wroc.pwr.ds.api.MyRemoteService;
import pl.edu.wroc.pwr.ds.api.RemoteObserver;
import pl.edu.wroc.pwr.ds.api.Worker_Check;
import pl.edu.wroc.pwr.ds.api.MyRemoteCallback;

public class MyRemoteServiceImpl extends Observable implements MyRemoteService{
	
	ArrayList<WrappedObserver>listaObserver=new ArrayList<WrappedObserver>();
	ArrayList<Worker_Check>listaWorker=new ArrayList<Worker_Check>();
	ArrayList<Integer>listaLiczb;
	 int  count;
	
	private class WrappedObserver implements Observer, Serializable {

        private static final long serialVersionUID = 1L;

        private RemoteObserver ro = null;

        public WrappedObserver(RemoteObserver ro) {
            this.ro = ro;
        }

        @Override
        public void update(Observable o, Object arg) {
            try {
                ro.update(o.toString(), arg);
            } catch (RemoteException e) {
                System.out
                        .println("Remote exception removing observer:" + this);
                o.deleteObserver(this);
            }
        }
        
       

    }
	public void addWorker(Worker_Check w)
	{
		listaWorker.add(w);
	}
	
	@Override
    public void addObserver(RemoteObserver o) throws RemoteException {
        WrappedObserver mo = new WrappedObserver(o);
        addObserver(mo);
        System.out.println("Added observer:" + mo);
        listaObserver.add(mo);
    }
	
	Thread thread = new Thread() {
        @Override
        public void run() {
            while (true) {
                try {
                    Thread.sleep(5 * 1000);
                } catch (InterruptedException e) {
                    // ignore
                }
                setChanged();
                notifyObservers(new Date());
            }
        };
    };

  	final static Logger logger = Logger.getLogger(MyRemoteServiceImpl.class);

	private String param;
	public MyRemoteServiceImpl(String param){
		this.param=param;
		logger.info("Constructor");
	}


	public void getMessage(String data, MyRemoteCallback callback) throws RemoteException{
		logger.info("Method call");
		callback.callback(String.format("Hello %s in %s", data, this.param));
	}
	
	public void pokaz()
	{
		for(WrappedObserver worker:listaObserver)
		{
			logger.info(String.format("Nazwa- %s", worker));
		}
	}

	@Override
	public void getLista(ArrayList<Integer> lista) throws RemoteException {
		// TODO Auto-generated method stub
		listaLiczb=lista;
	}

	@Override
	public boolean[] sprawdz(ArrayList<Integer> lista) throws RemoteException {
		// TODO Auto-generated method stub
		ArrayList<Integer>listaLiczb=lista;
		boolean[]wyniki=new boolean[listaLiczb.size()];
		
		//boolean[]wyniki2=new boolean[listaLiczb.size()];
		Random r=new Random();
		int k=0;
		for(int i=0;i<wyniki.length;i++)
		{
			if(k>=listaWorker.size())
				k=0;
			
			wyniki[i]=listaWorker.get(k).check(listaLiczb.get(i));
			
			k++;
	
		}
		//wyniki2=listaWorker.parallelStream().forEachOrdered());;
		return wyniki;
	}

	@Override
	public int ileGotowych() throws RemoteException {
		// TODO Auto-generated method stub
	/*	count=0;
		listaWorker.parallelStream().forEach(e-> {try {
			
			if(e.czyGotowy()) count++;
		} catch (RemoteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}});
		return count;*/
		
		return (int) listaWorker.parallelStream().filter(e -> {
			try {
				return e.czyGotowy();
			} catch (RemoteException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				throw new RuntimeException(e1);
			}
		}).count();}
	
}
package pl.edu.wroc.pwr.ds;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Random;

import org.apache.log4j.Logger;
import pl.edu.wroc.pwr.ds.api.RemoteObserver;
import pl.edu.wroc.pwr.ds.api.Worker_Check;

public class Worker_CheckImpl /*extends UnicastRemoteObject*/ implements RemoteObserver, Worker_Check{
	/*protected Worker_CheckImpl() throws RemoteException {
		//super();
		// TODO Auto-generated constructor stub
	}*/



	/**
	 * 
	 */
	
	final static Logger logger = Logger.getLogger(Worker_CheckImpl.class);
	
	public boolean check(int n) throws RemoteException {		
		// TODO Auto-generated method stub
		{ 
			logger.info("Czy "+n+" jest pierwsza?");
			boolean czy=false;
	            if (n>2) 
	            { 
	            	double sq = Math.sqrt(n); 
	            	if(n%2==0) 
	            		czy=false; 
	                    else 
	                    { 
	                    	for(int i=3; i<=sq; i+=2) 
	                    	{ 
	                         if(n%i==0) 
	                         { 
	                         czy= false; 
	                         } 
	                    	} 
	                            czy= true; 
	                    } 
	             } else if (n==2) 
	            	 czy= true; 
		
	            return czy;
	    }
		
	
	}
	
/*
	@Override
    public void update(Object observable, Object updateMsg)
            throws RemoteException {
        System.out.println("got message:" + updateMsg);
    }
*/

	@Override
	public void update(Object observable, Object updateMsg) throws RemoteException {
		System.out.println("wiedz ze cos sie dziej");
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean czyGotowy() throws RemoteException {
		// TODO Auto-generated method stub
		Random r=new Random();
		
		int k=r.nextInt(10);
		if(k<7)
			return true;
		else
		return false;
	}

	
}

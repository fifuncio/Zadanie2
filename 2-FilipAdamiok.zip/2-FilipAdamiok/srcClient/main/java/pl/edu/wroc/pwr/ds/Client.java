package pl.edu.wroc.pwr.ds;
import org.apache.log4j.Logger;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import pl.edu.wroc.pwr.ds.api.MyRemoteService;
import pl.edu.wroc.pwr.ds.api.MyRemoteCallback;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

/**
 * Hello world client!
 *
 */
public class Client{

  	final static Logger logger = Logger.getLogger(Client.class);

	// Throws in here is really ugly :(
    public static void main( String[] args ) throws Exception{
    	logger.info("Creating client");
        Registry registry = LocateRegistry.getRegistry("localhost", 8080);
        //MyRemoteCallbackImpl callback = new MyRemoteCallbackImpl();
       // MyRemoteCallback remoteCallback =(MyRemoteCallback) UnicastRemoteObject.exportObject(callback,0 );
        MyRemoteService obj = (MyRemoteService) registry.lookup("MyRemoteService");
        ArrayList<Integer>lista=new ArrayList<Integer>();
        lista.add(8);
        lista.add(12);
        lista.add(13);
        lista.add(16);
        lista.add(17);
       // obj.getLista(lista);
        boolean[] wynik=obj.sprawdz(lista);
        for(int i=0;i<wynik.length;i++)
        {
        	if(wynik[i])
        		System.out.println("Liczba "+lista.get(i)+" jest liczbą pierwszą");
        	else
        		System.out.println("Liczba "+lista.get(i)+" nie jest liczbą pierwszą");
        }
        
        int ile=obj.ileGotowych();
        
        System.out.println("Ilosc dostępnych workerow- "+ile);
        
       	
    }
    
}
